import { menuController } from 'https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/index.esm.js';

async function openMenu() {
  await menuController.open();
}

var props = {
  openMenu: openMenu
};
