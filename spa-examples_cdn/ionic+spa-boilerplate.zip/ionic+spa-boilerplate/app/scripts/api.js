app.api = {
  mock: true

};

app.api.urls = {

  inbox: 'api-v1/list/inbox',

  outbox: 'api-v1/list/outbox'

};