var _target = '#main-container';

var _dataUrl = '@outbox';

// properties and functions specific to outbox










// export properties and functions to app.outbox.XYZ
var props = {

};