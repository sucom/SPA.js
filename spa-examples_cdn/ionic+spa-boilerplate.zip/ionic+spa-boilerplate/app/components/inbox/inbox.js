var _target = '#main-container';

var _dataUrl = '@inbox';

// properties and functions specific to inbox










// export properties and functions to app.inbox.XYZ
var props = {

};