import { menuController } from 'https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/index.esm.js';

async function openMenu() {
  await menuController.open();
}

async function closeMenu() {
  await menuController.close();
}

function home (  ) {
  closeMenu();

  render('home');
}

function inbox (  ) {
  closeMenu();
  render('inbox');
}

function outbox (  ) {
  closeMenu();
  render('outbox');
}

var props = {
  openMenu: openMenu,
  home: home,
  inbox: inbox,
  outbox: outbox
};