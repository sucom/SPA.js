spa.$extend('dataStore', {

  members: [
    {
      "id": 1,
      "first_name": "Cordey",
      "last_name": "Janous",
      "email": "cjanous0@guardian.co.uk",
      "gender": "Female"
    }, {
      "id": 2,
      "first_name": "Teodoor",
      "last_name": "Swapp",
      "email": "tswapp1@ft.com",
      "gender": "Male"
    }, {
      "id": 3,
      "first_name": "Brynne",
      "last_name": "MacLoughlin",
      "email": "bmacloughlin2@npr.org",
      "gender": "Female"
    }, {
      "id": 4,
      "first_name": "Claudetta",
      "last_name": "Shortan",
      "email": "cshortan3@cloudflare.com",
      "gender": "Female"
    }, {
      "id": 5,
      "first_name": "Eadmund",
      "last_name": "Way",
      "email": "eway4@ask.com",
      "gender": "Male"
    }]

});