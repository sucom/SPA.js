spa.$extend('dataStore', {

  member: {
    name: 'Name in [dataStore] component scope'
  }

});