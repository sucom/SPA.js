spa.$('compX', {

  templateScript: true, // <script> tags are blocked in component html by default until SPA.js v2.81.1

  test: function () {

    console.group('inside compX.test()');

    // using lib1, lib2 imports in index.html
    console.log( lib1.sum(1, 2, 3) );
    console.log( lib2.mul(1, 2, 3) );

    // using lib3, lib4 imports in compX.html
    console.log( lib3.sum(1, 2, 3) );
    console.log( lib4.mul(1, 2, 3) );

    console.groupEnd('inside compX.test()');

  }
});