spa.$('compY', {

  test1: function () {

    console.group('inside compY.test1()');

    // using lib1, lib2 imports in index.html
    console.log( 'using index.html static imports' );
    console.log( lib1.sum(1, 2, 3) );
    console.log( lib2.mul(1, 2, 3) );

    // using lib3, lib4 imports in compX.html; NOTE: this will be available only after compX render
    console.log( 'using compX.html static imports' );
    console.log( lib3.sum(1, 2, 3) );
    console.log( lib4.mul(1, 2, 3) );

    console.groupEnd('inside compY.test1()');
  },

  test2: function () {

    // using dynamic import - single
    console.log( 'using dynamic import' );

    import('./modules/module1.js').then( lib5 => {
      console.log( lib5.sum(1, 2, 3) );
    } );

  },

  test3: async function () {

    // using dynamic import - multiple
    console.group('using multiple dynamic imports');

    let lib6 = await import('./modules/module1.js');
    let lib7 = await import('./modules/module2.js');
    console.log( lib6.sum(1, 2, 3) );
    console.log( lib7.mul(1, 2, 3) );

    console.groupEnd('using multiple dynamic imports');
  }

});