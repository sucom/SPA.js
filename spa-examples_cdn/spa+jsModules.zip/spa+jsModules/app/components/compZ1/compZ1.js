(function () {
  import('./modules/module1.js').then(libA => {
    console.group('inside anonymous single import');
    console.log( libA.sum(1, 2, 3) );

    // export to window so component methods can access.
    window.libZ1 = libA;
    console.groupEnd('inside anonymous single import');
  });
})();

spa.$('compZ1', {

  test: function () {

    // using above import - single
    console.log( 'using dynamically imported (single) module in compZ1.js' );

    console.log( libZ1.sum(1, 2, 3) );

  }
});