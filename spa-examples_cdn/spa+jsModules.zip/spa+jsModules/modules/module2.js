console.log('inside module2.js');

const PI = 3.1415926;

function mul(...args) {
  log('mul', args);
  return args.reduce((num, tot) => tot * num);
}

// private function
function log(...msg) {
  console.log(...msg);
}

export { PI, mul };