spa.$('viewForm3', {

  target: '#containerComponent',

  style: '.',

  data: {
    "id": 1,
    "firstName": "Cordey",
    "lastName": "Janous",
    "email": "em@ail.com",
    "gender": "Female",
    "active": true
  }

});