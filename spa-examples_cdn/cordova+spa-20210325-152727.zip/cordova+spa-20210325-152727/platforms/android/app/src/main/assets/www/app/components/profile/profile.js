
var _dataUrl = 'https://reqres.in/api/users/{pid}';

var _dataUrlParams = {pid: 1};
