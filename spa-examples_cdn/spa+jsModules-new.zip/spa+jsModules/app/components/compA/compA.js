import * as libA1 from './modules/module1.js';
import * as libA2 from './modules/module2.js';

spa.$('compA', {

  test: function () {

    console.group('inside compA.test()');

    // using lib1, lib2 imports in index.html
    console.log( lib1.sum(1, 2, 3) );
    console.log( lib2.mul(1, 2, 3) );

    // using libA1, libA2 imports in compX.html
    console.log( libA1.sum(1, 2, 3) );
    console.log( libA2.mul(1, 2, 3) );

    console.groupEnd('inside compA.test()');

  }
});