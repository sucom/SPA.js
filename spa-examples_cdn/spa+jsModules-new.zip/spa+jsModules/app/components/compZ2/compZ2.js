let utilLib1, utilLib2;

(async function () {

  let libB = await import('./modules/module1.js');
  let libC = await import('./modules/module2.js');

  // export outside to this function. so, the component methods can access.
  utilLib1 = libB;
  utilLib2 = libC;

  console.group('inside anonymous multi import');
  console.log( libB.sum(1, 2, 3) );
  console.log( libC.mul(1, 2, 3) );
  console.groupEnd('inside anonymous multi import');
})();

spa.$('compZ2', {

  test: function () {

    // using above import - multiple
    console.log( 'using dynamically imported (multiple) modules in compZ2.js' );

    console.log( utilLib1.sum(1, 2, 3) );
    console.log( utilLib2.mul(1, 2, 3) );

  }
});