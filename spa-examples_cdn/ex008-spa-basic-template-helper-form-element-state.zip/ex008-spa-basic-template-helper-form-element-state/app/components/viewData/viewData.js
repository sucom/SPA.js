spa.$('viewData', {
  require: 'dataStore',

  data: {
    "id": 1,
    "firstName": "Cordey",
    "lastName": "Janous",
    "email": "cjanous0@guardian.co.uk",
    "gender": "Female",
    "active": true,
    "allowUpdate": false
  }

});