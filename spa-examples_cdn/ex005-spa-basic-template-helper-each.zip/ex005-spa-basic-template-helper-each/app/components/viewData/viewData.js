spa.$('viewData', {
  dataUrl:'local:appData'
});