
function _renderCallback () {

  const button = document.querySelector('ion-button');
  button.addEventListener('click', handleButtonClick);

  async function handleButtonClick() {
    const actionSheet = await actionSheetController.create({
      header: 'Albums',
      buttons: [{
          text: 'Delete',
          role: 'destructive'
        },
        {
          text: 'Share'
        },
        {
          text: 'Play'
        },
        {
          text: 'Favorite'
        },
        {
          text: 'Cancel',
          role: 'cancel'
        }
      ]
    });

    await actionSheet.present();
  }
}