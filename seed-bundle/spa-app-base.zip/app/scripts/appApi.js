/* SPA API: Refer to online documentation (https://spa.js.org/#getStarted/spaApi) for more details */
