/* Global/Common app settings and utils */
spa.onReady = function () {
  spa.$render('home', {target: '#containerHome'});
};
