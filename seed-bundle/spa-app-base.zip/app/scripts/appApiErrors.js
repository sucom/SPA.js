$.extend(spa.api, {

/*
  onReqError: function (jqXHR, textStatus, errorThrown) {
    //This function is to handles if Ajax request itself failed
    //due to network error / server error
    //like 400 / 401 / 403/ 404 / 408 / 500 / etc.
    //use jqXHR.status for the HTTP ERROR CODE

    //doSomething for the HTTP REQUEST ERROR
    //console.log(jqXHR, textStatus, errorThrown);

  }

  ,
  isCallSuccess: function (axResponse) {
    //Validate Response with your logic here.

    //Example:
    //return (_.isObject(axResponse)
    //        && axResponse.hasOwnProperty('axcode')
    //        && (axResponse.axcode == 0));

    // must return true/false;

    //true forward the execution control to Component-Render or
    //API’s successFunction

    //false forward the execution control to spa.api.onResError
  }

  ,
  onResError: function (axRes) {
    //TODO: DevTeam
    //This function is to handle when API response returns exceptions/errors
    //like when axResponse.axcode != 0

    //if (axRes.hasOwnProperty('axcode')) {
    //} else {
    //  alert('API responded with error. Check console for more info.');
    //}
  }
*/

});