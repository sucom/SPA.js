spa.$('footer', {
  style:'.',
  data: { companyName: 'XYZ Inc' }
});