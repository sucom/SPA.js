/*
 * https://www.freecodecamp.org/news/how-to-write-a-jquery-like-library-in-71-lines-of-code-learn-about-the-dom-e9fb99dbc8d2/
 */

var dom = (function(global){

  var _arrProto = Array.prototype;

  function _qryElements (selector, context) {
    var _selector = selector;
    var _context  = context;
    var elements  = [];

    selector = _selector || 'html';
    context  = _context || document;
    try {
      if (context !== document) {
        context = _qryElements(context);
        if (context && context.length) {
          if (context.length === 1) {
            context = context[0];
          }
        } else {
          context = null;
        }
      }

      if (selector instanceof DOMElements) {
        elements = selector;
      } else if (typeof selector === 'function') {
        // TODO: document onReady function
        console.log('TODO: document onReady function');
      } else if (typeof selector === 'string') {
        selector = selector.trim();

        if (selector === 'document') {
          elements = [document];
        } else if (selector === 'window') {
          elements = [window];
        } else {
          if (/^\s*</.test(selector)) {
            var dynEl = document.createElement('div');
            dynEl.id = 'dQvDOM'+(+(new Date()));
            dynEl.innerHTML = selector;
            for (var i=0; i<dynEl.childNodes.length; i++) {
              var child = dynEl.childNodes[i];
              if (child.nodeType == 1) {
                elements.push(child);
              }
            }
          } else {
            if (!context) {
              console.error('Invalid Context', _context);
            } else if (context.querySelectorAll) {
              var nodes = context.querySelectorAll(selector);
              if (nodes) {
                elements = [].slice.call(nodes);
              }
            } else if (context.length) {
              for (var cElIdx=0; cElIdx<context.length; cElIdx++) {
                elements = elements.concat( _qryElements(selector, context[cElIdx]) );
              }
            } else {
              console.warn('Unable to find elements in context', {selector: _selector , context: _context});
            }
          }
        }
      } else if (typeof selector === 'object' && selector.hasOwnProperty('length') && selector['splice']) {
        elements = selector;
      } else {
        elements = [selector];
      }
    } catch ( e ) {
      console.error('ERROR: Invalid Selector/Context', {selector: _selector , context: _context}, e);
    }

    return elements;
  }

  function DOMElements (selector, context) {
    this.length   = 0;
    var elements = _qryElements(selector, context);
    try {
      if (elements && elements.length) {
        this.length = elements.length;
        for(var i=0;i<this.length;i++) {
          this[i] = elements[i];
        }
      }
    } catch (e) {}
  }
  var domElProto = DOMElements.prototype;
  domElProto.isDomQry = true;
  // ---------Immutable Array Functions------
  domElProto.splice   = noop;
  domElProto.slice    = _arrProto.slice;
  domElProto.forEach  = _arrProto.forEach;
  domElProto.map      = _arrProto.map;
  domElProto.every    = _arrProto.every;
  domElProto.some     = _arrProto.some;

  domElProto.each     = each;
  domElProto.find     = find;
  domElProto.filter   = filter;
  // ----------------------------------------
  domElProto.addClass    = addClass;
  domElProto.removeClass = removeClass;
  domElProto.toggleClass = toggleClass;
  domElProto.hasClass    = hasClass;

  domElProto.show    = show;
  domElProto.hide    = hide;

  domElProto.id      = todo;
  domElProto.ids     = todo;
  domElProto.name    = todo;
  domElProto.names   = todo;
  domElProto.value   = todo;
  domElProto.values  = todo;

  domElProto.class  = todo;
  domElProto.style  = todo;
  domElProto.css    = todo;

  domElProto.hasAttr = prop;
  domElProto.attr    = attr;
  domElProto.prop    = prop;
  domElProto.is      = isProp;

  domElProto.html    = todo;
  domElProto.text    = todo;
  domElProto.val     = todo;
  domElProto.data    = todo;

  domElProto.append  = todo;
  domElProto.prepend = todo;
  domElProto.remove  = todo;

  domElProto.select       = todo;
  domElProto.focus        = todo;
  domElProto.enable       = todo;
  domElProto.disable      = todo;
  domElProto.isEnabled    = todo;
  domElProto.isDisabled   = todo;

  domElProto.closest      = todo;
  domElProto.parent       = todo;
  domElProto.children     = todo;
  domElProto.siblings     = todo;
  domElProto.siblingsPrev = todo;
  domElProto.siblingsNext = todo;
  domElProto.first        = todo;
  domElProto.last         = todo;
  domElProto.next         = todo;
  domElProto.prev         = todo;

  domElProto.on      = todo;
  domElProto.off     = todo;
  domElProto.trigger = todo;

  // ========================================
  function init (selector, context) {
    if (selector instanceof DOMElements) return selector;
    return new DOMElements(selector, context);
  }
  function dQ (selector, context) {
    return init(selector, context);
  }
  dQ.ready = function ( onReadyFn ){
    if (typeof onReadyFn === 'function') {
      console.log('TODO: on document ready...');
    }
  }

  // ========================================
  function todo () {
    console.log('TODO ...');
    return this;
  }
  function noop () {
    return this;
  }
  function each ( fn ) {
    if (typeof fn !== 'function') return;
    for (var i = 0; i < this.length ; i++) {
      fn(this[i], i);
    }
  }
  function find ( selector ) {
    return dQ(selector, this);
  }
  function filter ( selector ) {
    var filteredItems = [];
    if (typeof selector === 'string') {
      for (var i=0; i<this.length; i++) {
        if (this[i].matches( selector )) filteredItems.push(this[i]);
      }
    } else if (typeof selector === 'function') {
      for (var i=0; i<this.length; i++) {
        if (selector(this[i], i)) filteredItems.push(this[i]);
      }
    }
    return dQ(filteredItems);
  }
  // ========================================

  // ========================================
  function nameList () {
    var args = [].slice.call(arguments);
    var classNames = [];
    (args.join(' ')).replace(/[.,]/g,' ').split(' ').forEach(function(className){
      className = (className||'').trim();
      (className && classNames.push(className));
    });
    return classNames;
  }
  function _Class () {
    var args = [].slice.call(arguments);
    var operation  = args.shift();
    var classNames = nameList.apply(undefined, args);
    if (classNames.length) {
      this.each(function(el){
        classNames.forEach(function(className){
          el.classList[operation](className);
        });
      });
    }

    return this;
  }
  function addClass () {
    return _Class.apply(this, ['add'].concat([].slice.call(arguments)));
  }
  function removeClass () {
    return _Class.apply(this, ['remove'].concat([].slice.call(arguments)));
  }
  function toggleClass () {
    return _Class.apply(this, ['toggle'].concat([].slice.call(arguments)));
  }
  function hasClass () {
    var classNames = nameList.apply(undefined, [].slice.call(arguments));
    if (classNames.length) {
      return this.every(function(el){
        return classNames.every(function(className){
          return el.classList.contains(className);
        });
      });
    }
  }

  // --------------------------------------------
  function show () {
    var mode = arguments[0] || 'block';
    this.each(function(el){
      el.style.display = mode;
    });
  }
  function hide () {
    this.each(function(el){
      el.style.display = 'none';
    });
  }
  // --------------------------------------------
  function attr ( attr ) {
    var retValue = (this[0] && this[0]['getAttribute'])? this[0].getAttribute(attr) : '';
    if (arguments.length === 2) {
      this.each(function(el){
        el['setAttribute'] && el.setAttribute(attr, arguments[1]);
      });
      retValue = this;
    }
    return retValue;
  }
  function prop () {
    if (!this.length) {
      return (arguments.length === 2)? this : false;
    };
    var retValue = this;
    var attrNames = nameList.call(undefined, arguments[0]);
    if (attrNames.length) {
      if (arguments.length === 2) {
        var setProp = arguments[1];
        this.each(function(el){
          attrNames.forEach(function(attrName){
            if (setProp) {
              el.setAttribute(attrName, attrName);
            } else {
              el.removeAttribute(attrName);
            }
          });
        });
      } else {
        retValue = this.every(function(el){
          return attrNames.every(function(attrName){
            return el.hasAttribute(attrName);
          });
        });
      }
    }
    return retValue;
  }

  function isProp ( matchSpecs ) {
    if (!(this.length && arguments.length)) { return false; };
    var retValue = this;

    var matchList = [];
    (''+matchSpecs).replace(/,/g,' ').split(' ').forEach(function(matchSpec){
      matchSpec = (matchSpec||'').trim();
      (matchSpec && matchList.push(matchSpec));
    });

    if (matchList.length) {
      retValue = this.every(function(el){
        return matchList.every(function(attrName){
          switch (attrName.toLowerCase()) {
            case ':disabled' :
              return el.hasAttribute('disabled');
            case ':enabled' :
              return !el.hasAttribute('disabled');
            case ':checked' :
            case ':selected':
              return el.hasAttribute('checked') || el.hasAttribute('selected');
            case ':visible':
              break;
            case ':hidden':
              break;
            default:
              if (attrName[0] === '[') {
                var elAttrNameValue = attrName.slice(1,-1).split('=');
                var eAttrN = elAttrNameValue[0];
                var eAttrV = elAttrNameValue[1];
                if (eAttrV) {
                  console.log('TODO:');
                } else {
                  return el.hasAttribute(eAttrN);
                }
              } if ((/^:not/i).test(attrName)) {
                console.log('TODO :not()');
              } else {
                return false;
              }
          }
        });
      });
    }
    return retValue;
  }

  // --------------------------------------------
  // --------------------------------------------

  return dQ;
})(this);